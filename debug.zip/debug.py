def echo(body, **extras):
    print(f"{body=} " + " ".join(f"{k}={v!r}" for k, v in extras.items()))
